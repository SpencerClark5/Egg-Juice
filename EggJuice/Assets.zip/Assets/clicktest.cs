using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class clicktest : MonoBehaviour
{
    // Start is called before the first frame update
    public void OnMouseDown()
    {
        Debug.Log("egg clicked");
    }
}
